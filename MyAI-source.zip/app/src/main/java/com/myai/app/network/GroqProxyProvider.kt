package com.myai.app.network

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.util.concurrent.TimeUnit

@Serializable
private data class ProxyMessage(val role: String, val content: String)

@Serializable
private data class ProxyRequest(
    val model: String,
    val messages: List<ProxyMessage>,
    val stream: Boolean = true,
    val max_tokens: Int = 2048
)

/**
 * Talks to a small Cloudflare Worker proxy (see /proxy/worker.js) instead of
 * calling Groq directly. The proxy holds the real Groq API key server-side
 * as an encrypted Cloudflare secret. Nothing secret is stored in this app or
 * shipped inside the APK, so decompiling the app reveals nothing usable —
 * yet no user ever has to create an account or paste a key. Every user gets
 * a fully free, zero-setup chat experience.
 */
class GroqProxyProvider : AiProvider {

    // Worker URL updated with your active deployment proxy
    private val proxyUrl = "https://my-ai-proxy.priyobiswas817.workers.dev/chat"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    override fun isConfigured(): Boolean = !proxyUrl.contains("REPLACE-WITH-YOUR-WORKER-URL")

    override fun streamReply(history: List<ChatTurn>, modelId: String): Flow<StreamEvent> = callbackFlow {
        if (!isConfigured()) {
            trySend(StreamEvent.Error("Proxy URL not configured", isAuthError = true))
            close()
            return@callbackFlow
        }

        val systemPrompt = "You are My AI, a friendly, knowledgeable assistant. " +
            "Always reply in the same language the user wrote in (Bangla, English, or any other language). " +
            "Use Markdown formatting, and put code in fenced code blocks with the correct language tag."

        val messages = listOf(ProxyMessage("system", systemPrompt)) +
            history.map { ProxyMessage(it.role, it.content) }

        val body = ProxyRequest(model = modelId, messages = messages)
        val requestJson = json.encodeToString(body)

        val request = Request.Builder()
            .url(proxyUrl)
            .addHeader("content-type", "application/json")
            .post(requestJson.toRequestBody("application/json".toMediaType()))
            .build()

        val listener = object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "[DONE]") {
                    trySend(StreamEvent.Done)
                    return
                }
                try {
                    val element: JsonElement = json.parseToJsonElement(data)
                    val obj = element.jsonObject
                    val errorObj = obj["error"]?.jsonObject
                    if (errorObj != null) {
                        val msg = errorObj["message"]?.jsonPrimitive?.content ?: "Unknown API error"
                        trySend(StreamEvent.Error(msg))
                        return
                    }
                    val choice = obj["choices"]?.jsonArray?.firstOrNull()?.jsonObject
                    val delta = choice?.get("delta")?.jsonObject
                    val text = delta?.get("content")?.jsonPrimitive?.content
                    if (!text.isNullOrEmpty()) trySend(StreamEvent.Delta(text))
                } catch (_: Exception) {
                    // Ignore malformed/partial SSE frames; the stream will continue.
                }
            }

            override fun onClosed(eventSource: EventSource) {
                trySend(StreamEvent.Done)
                close()
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: okhttp3.Response?) {
                val code = response?.code
                val isAuth = code == 401 || code == 403
                val message = when {
                    isAuth -> "Proxy authentication error — check the Worker's GROQ_API_KEY secret"
                    code == 429 -> "Rate limited — please wait and try again"
                    code != null -> "Server error ($code)"
                    else -> t?.message ?: "Network error"
                }
                trySend(StreamEvent.Error(message, isAuthError = isAuth))
                close()
            }
        }

        val eventSource = EventSources.createFactory(client).newEventSource(request, listener)
        awaitClose { eventSource.cancel() }
    }
}
ckage