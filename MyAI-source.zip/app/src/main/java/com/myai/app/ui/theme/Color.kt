package com.myai.app.ui.theme

import androidx.compose.ui.graphics.Color

val BrandPrimaryLight = Color(0xFF5B5BF0)
val BrandPrimaryDark = Color(0xFF8A8AFF)

val SurfaceLight = Color(0xFFFAFAFC)
val SurfaceDark = Color(0xFF121218)

val BubbleUserLight = Color(0xFF5B5BF0)
val BubbleUserDark = Color(0xFF4A4AD9)

val BubbleAiLight = Color(0xFFF0F0F5)
val BubbleAiDark = Color(0xFF1E1E28)

val CodeBlockLight = Color(0xFF1E1E28)
val CodeBlockDark = Color(0xFF0A0A0F)
