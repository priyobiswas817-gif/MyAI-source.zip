package com.myai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.myai.app.data.AiModel
import com.myai.app.data.AppContainer
import com.myai.app.data.AppTheme
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    container: AppContainer,
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val settingsStore = container.settingsStore
    val scope = rememberCoroutineScope()
    var showClearConfirm by remember { mutableStateOf(false) }

    val theme by settingsStore.theme.collectAsState(initial = AppTheme.SYSTEM)
    val model by settingsStore.model.collectAsState(initial = AiModel.LLAMA_70B)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column {
                Text(
                    "Powered by Groq — completely free, nothing to set up.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Divider()

            Column {
                Text("Theme", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                SingleChoiceSegmentedButtonRow {
                    AppTheme.values().forEachIndexed { index, t ->
                        SegmentedButton(
                            selected = theme == t,
                            onClick = { scope.launch { settingsStore.setTheme(t) } },
                            shape = SegmentedButtonDefaults.itemShape(index, AppTheme.values().size)
                        ) {
                            Text(
                                when (t) {
                                    AppTheme.SYSTEM -> "System"
                                    AppTheme.LIGHT -> "Light"
                                    AppTheme.DARK -> "Dark"
                                }
                            )
                        }
                    }
                }
            }

            Divider()

            Column {
                Text("AI Model", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AiModel.values().forEach { m ->
                        FilterChip(
                            selected = model == m,
                            onClick = { scope.launch { settingsStore.setModel(m) } },
                            label = { Text(m.displayName) }
                        )
                    }
                }
            }

            Divider()

            Column {
                Text("Data", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showClearConfirm = true }) {
                    Text("Clear all history")
                }
            }

            Divider()

            Column {
                Text("About", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    "My AI — free, ready to use instantly, no account or key needed. Chat in Bangla, English, or any language.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear all history?") },
            text = { Text("All chats and messages will be permanently deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAllHistory()
                    showClearConfirm = false
                }) { Text("Clear") }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") }
            }
        )
    }
}
