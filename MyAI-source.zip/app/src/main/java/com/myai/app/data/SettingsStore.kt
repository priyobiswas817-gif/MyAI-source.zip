package com.myai.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "myai_settings")

enum class AppTheme { SYSTEM, LIGHT, DARK }

/**
 * Available AI models, served through the app's free Groq proxy (see
 * network/GroqProxyProvider.kt) — no user ever needs their own API key.
 * The app is provider-agnostic under the hood (network/AiProvider.kt) so a
 * different backend/model can be plugged in later without touching the UI.
 */
enum class AiModel(val id: String, val displayName: String) {
    LLAMA_70B("llama-3.3-70b-versatile", "Llama 3.3 70B (smart)"),
    LLAMA_8B("llama-3.1-8b-instant", "Llama 3.1 8B (fast)")
}

class SettingsStore(private val context: Context) {

    val theme: Flow<AppTheme> = context.dataStore.data.map { prefs ->
        prefs[THEME_KEY]?.let { runCatching { AppTheme.valueOf(it) }.getOrNull() } ?: AppTheme.SYSTEM
    }

    suspend fun setTheme(theme: AppTheme) {
        context.dataStore.edit { it[THEME_KEY] = theme.name }
    }

    val model: Flow<AiModel> = context.dataStore.data.map { prefs ->
        prefs[MODEL_KEY]?.let { id -> AiModel.values().find { it.id == id } } ?: AiModel.LLAMA_70B
    }

    suspend fun setModel(model: AiModel) {
        context.dataStore.edit { it[MODEL_KEY] = model.id }
    }

    companion object {
        private val THEME_KEY = stringPreferencesKey("theme")
        private val MODEL_KEY = stringPreferencesKey("model")
    }
}
